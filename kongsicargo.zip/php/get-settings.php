<?php
echo file_get_contents("../systemdata/settings.json");